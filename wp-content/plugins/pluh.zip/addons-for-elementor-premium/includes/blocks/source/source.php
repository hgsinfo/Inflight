<?php

namespace LivemeshAddons\Modules\Source;

/**
 * Class LAE_Source
 * @package LivemeshAddons\Modules\Source
 */
class LAE_Source {

    public $settings;

    function __construct($settings) {

        $this->settings = $settings;
    }

}